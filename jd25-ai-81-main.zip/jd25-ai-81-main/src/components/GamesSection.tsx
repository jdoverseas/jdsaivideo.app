
import React from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Gamepad, Trophy, Users, Star, Atom, Beaker } from "lucide-react";
import { Link } from "react-router-dom";

interface GameCardProps {
  title: string;
  description: string;
  image: string;
  category: string;
  rating: number;
  players: string;
  link?: string;
}

const GameCard: React.FC<GameCardProps> = ({ title, description, image, category, rating, players, link = "#" }) => {
  return (
    <Card className="overflow-hidden transition-all hover:shadow-lg hover:-translate-y-1">
      <div className="aspect-video relative overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-full object-cover transition-transform hover:scale-105"
        />
        <div className="absolute top-2 right-2 bg-primary/90 text-white text-xs px-2 py-1 rounded-full">
          {category}
        </div>
      </div>
      <CardHeader className="pb-2">
        <CardTitle>{title}</CardTitle>
        <CardDescription className="flex items-center justify-between">
          <span className="flex items-center">
            <Star className="w-4 h-4 text-yellow-500 mr-1" />
            {rating}/5
          </span>
          <span className="flex items-center">
            <Users className="w-4 h-4 mr-1" />
            {players}
          </span>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">{description}</p>
      </CardContent>
      <CardFooter>
        <Button className="w-full" asChild={!!link}>
          {link !== "#" ? (
            <Link to={link}>খেলুন</Link>
          ) : (
            "খেলুন"
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};

const GamesSection: React.FC = () => {
  const games = [
    {
      title: "বিজ্ঞান সূত্র গেম",
      description: "পদার্থবিজ্ঞান, রসায়ন, এবং কৃত্রিম বুদ্ধিমত্তা (এআই) এর সূত্র শিখতে এই মজার গেমটি খেলুন। প্রতি ৪০ দিন নতুন আপডেট।",
      image: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=800&auto=format&fit=crop",
      category: "শিক্ষামূলক",
      rating: 4.9,
      players: "৩ লাখ+",
      link: "/formula-game"
    },
    {
      title: "পাজল মাস্টার",
      description: "মস্তিষ্ক চর্চা করতে এই পাজল গেম খেলুন। বিভিন্ন স্তরের চ্যালেঞ্জ মোকাবেলা করুন।",
      image: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=800&auto=format&fit=crop",
      category: "পাজল",
      rating: 4.8,
      players: "৫ লাখ+"
    },
    {
      title: "কার রেসিং",
      description: "দ্রুত গতিতে গাড়ি চালিয়ে প্রতিপক্ষকে হারিয়ে দিন। অসাধারণ গ্রাফিক্স।",
      image: "https://images.unsplash.com/photo-1511882150382-421056c89033?w=800&auto=format&fit=crop",
      category: "রেসিং",
      rating: 4.6,
      players: "১০ লাখ+"
    },
    {
      title: "শব্দ খেলা",
      description: "আপনার শব্দভাণ্ডার বাড়াতে এই আকর্ষণীয় শব্দ গেমটি খেলুন।",
      image: "https://images.unsplash.com/photo-1516041762831-3d0f87c32156?w=800&auto=format&fit=crop",
      category: "শিক্ষামূলক",
      rating: 4.5,
      players: "৮ লাখ+"
    },
    {
      title: "সুপার ফাইটার",
      description: "বিভিন্ন চরিত্র বেছে নিয়ে লড়াই করুন এবং চ্যাম্পিয়ন হয়ে উঠুন।",
      image: "https://images.unsplash.com/photo-1523843268911-45a882919fec?w=800&auto=format&fit=crop",
      category: "অ্যাকশন",
      rating: 4.7,
      players: "১২ লাখ+"
    },
    {
      title: "ফার্মিং সিমুলেটর",
      description: "নিজের খামার তৈরি করুন, ফসল ফলান এবং পশুপালন করুন।",
      image: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=800&auto=format&fit=crop",
      category: "সিমুলেশন",
      rating: 4.4,
      players: "৬ লাখ+"
    },
    {
      title: "মজার পাখি",
      description: "সহজ কিন্তু আসক্তিকর, এই গেমটি আপনাকে ঘন্টার পর ঘন্টা ব্যস্ত রাখবে।",
      image: "https://images.unsplash.com/photo-1522926193341-e9ffd686c60f?w=800&auto=format&fit=crop",
      category: "ক্যাজুয়াল",
      rating: 4.9,
      players: "২০ লাখ+"
    },
  ];

  return (
    <section id="games" className="py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">জনপ্রিয় গেমস</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            আমাদের সেরা ও জনপ্রিয় গেমগুলো দেখুন। প্রতিদিন নতুন নতুন গেম যোগ করা হচ্ছে।
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.map((game, index) => (
            <GameCard key={index} {...game} />
          ))}
        </div>

        <div className="mt-16 text-center">
          <Button variant="outline" size="lg" className="mx-auto">
            <Gamepad className="mr-2" />
            আরও গেমস দেখুন
          </Button>
        </div>
      </div>
    </section>
  );
};

export default GamesSection;
