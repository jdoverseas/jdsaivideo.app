
import React, { useEffect, useRef } from "react";

const SpecsSection: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      const elements = sectionRef.current.querySelectorAll(".page-transition-element");
      elements.forEach((el) => observer.observe(el));
    }

    return () => {
      if (sectionRef.current) {
        const elements = sectionRef.current.querySelectorAll(".page-transition-element");
        elements.forEach((el) => observer.unobserve(el));
      }
    };
  }, []);

  return (
    <section
      id="specs"
      ref={sectionRef}
      className="py-24 px-6 md:py-32 bg-gradient-to-b from-secondary/50 to-background"
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 md:mb-24">
          <span className="inline-block px-3 py-1 mb-4 text-xs font-medium rounded-full bg-primary/10 text-primary page-transition-element">
            Specifications
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 page-transition-element">
            Technical Excellence
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto page-transition-element">
            Precision-engineered with the finest components for optimal performance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          <div className="page-transition-element">
            <div className="glass-effect rounded-2xl p-8">
              <h3 className="text-xl font-semibold mb-6 border-b border-border pb-4">Physical Dimensions</h3>
              <dl className="space-y-4">
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Height</dt>
                  <dd className="font-medium">120 mm (4.7 inches)</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Width</dt>
                  <dd className="font-medium">70 mm (2.8 inches)</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Depth</dt>
                  <dd className="font-medium">7.6 mm (0.3 inches)</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Weight</dt>
                  <dd className="font-medium">135 grams (4.8 ounces)</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Materials</dt>
                  <dd className="font-medium">Aerospace-grade aluminum</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Finish</dt>
                  <dd className="font-medium">Matte anodized surface</dd>
                </div>
              </dl>
            </div>
          </div>

          <div className="page-transition-element">
            <div className="glass-effect rounded-2xl p-8">
              <h3 className="text-xl font-semibold mb-6 border-b border-border pb-4">Technical Specifications</h3>
              <dl className="space-y-4">
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Processor</dt>
                  <dd className="font-medium">Quad-core 2.4 GHz</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Memory</dt>
                  <dd className="font-medium">8GB LPDDR5</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Storage</dt>
                  <dd className="font-medium">128GB / 256GB / 512GB</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Battery Life</dt>
                  <dd className="font-medium">Up to 18 hours</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Connectivity</dt>
                  <dd className="font-medium">Wi-Fi 6E, Bluetooth 5.2</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Sensors</dt>
                  <dd className="font-medium">LiDAR, Accelerometer, Gyroscope</dd>
                </div>
              </dl>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SpecsSection;
