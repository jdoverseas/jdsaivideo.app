
import React from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Cpu, BrainCircuit, NetworkIcon, Waves, Braces, Sigma } from "lucide-react";

interface AITopicProps {
  title: string;
  description: string;
  formula: string;
  explanation: string;
  icon: React.ReactNode;
  lastUpdated: string;
}

const AITopic: React.FC<AITopicProps> = ({ title, description, formula, explanation, icon, lastUpdated }) => {
  return (
    <Card className="overflow-hidden transition-all hover:shadow-lg">
      <CardHeader className="bg-gradient-to-r from-violet-500/10 to-purple-500/10">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="bg-primary/10 p-2 rounded-full">{icon}</div>
            <CardTitle className="text-lg">{title}</CardTitle>
          </div>
          <Badge variant="outline">{lastUpdated}</Badge>
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="pt-4">
        <div className="mb-4 p-3 bg-muted rounded-md overflow-x-auto">
          <code className="text-sm">{formula}</code>
        </div>
        <p className="text-sm text-muted-foreground">{explanation}</p>
      </CardContent>
    </Card>
  );
};

const AIFormulaContent: React.FC = () => {
  const aiTopics = [
    {
      title: "লজিস্টিক রিগ্রেশন",
      description: "বাইনারি ক্লাসিফিকেশন মডেল - এআই এর একটি মৌলিক অ্যালগরিদম",
      formula: "P(y=1) = 1 / (1 + e^(-z)), যেখানে z = β₀ + β₁x₁ + β₂x₂ + ... + βₙxₙ",
      explanation: "লজিস্টিক ফাংশন ব্যবহার করে, এটি ইনপুট ভ্যারিয়েবলগুলিকে 0 এবং 1 এর মধ্যে একটি সম্ভাবনায় রূপান্তর করে। β পরামিতিগুলি অপটিমাইজেশন প্রক্রিয়ার মাধ্যমে শেখা হয়।",
      icon: <Sigma className="h-5 w-5 text-primary" />,
      lastUpdated: "২০২৪-০১-১৫"
    },
    {
      title: "নিউরাল নেটওয়ার্ক অ্যাক্টিভেশন",
      description: "নিউরাল নেটওয়ার্কে ব্যবহৃত নন-লিনিয়ার অ্যাক্টিভেশন ফাংশন",
      formula: "ReLU(x) = max(0, x) \nSigmoid(x) = 1/(1+e^(-x))",
      explanation: "অ্যাক্টিভেশন ফাংশনগুলি নিউরাল নেটওয়ার্কে নন-লিনিয়ারিটি প্রবর্তন করে, যা জটিল প্যাটার্ন শেখার জন্য প্রয়োজনীয়। ReLU সাধারণত হিডেন লেয়ারে ব্যবহৃত হয়, সিগময়েড আউটপুট লেয়ারে।",
      icon: <BrainCircuit className="h-5 w-5 text-primary" />,
      lastUpdated: "২০২৪-০২-২৫"
    },
    {
      title: "স্টোকাস্টিক গ্রেডিয়েন্ট ডিসেন্ট",
      description: "ডিপ লার্নিং মডেল ট্রেনিং-এর জন্য অপটিমাইজেশন অ্যালগরিদম",
      formula: "θ = θ - η ∇J(θ), যেখানে η হল লার্নিং রেট",
      explanation: "SGD প্রতি ইটারেশনে ডেটাসেট থেকে র‍্যান্ডম স্যাম্পল নিয়ে মডেল পরামিতিগুলি আপডেট করে। এটি পরামিতি স্পেসে লস ফাংশনের গ্রেডিয়েন্টের বিপরীত দিকে ছোট ছোট পদক্ষেপে চলে।",
      icon: <Waves className="h-5 w-5 text-primary" />,
      lastUpdated: "২০২৪-০৩-১০"
    },
    {
      title: "ট্রান্সফর্মার অ্যাটেনশন মেকানিজম",
      description: "প্রাকৃতিক ভাষা প্রসেসিং মডেলের মূল গাণিতিক ভিত্তি",
      formula: "Attention(Q, K, V) = softmax(QK^T / √d_k)V",
      explanation: "ট্রান্সফর্মার মডেলে, কোয়েরি (Q), কী (K) এবং ভ্যালু (V) ম্যাট্রিক্সের মাধ্যমে শব্দের মধ্যে সম্পর্ক স্থাপন করা হয়। এই ফর্মুলা শব্দগুলির মধ্যে অর্থপূর্ণ সম্পর্ক ধরতে সাহায্য করে।",
      icon: <NetworkIcon className="h-5 w-5 text-primary" />,
      lastUpdated: "২০২৪-০৪-০৫"
    },
    {
      title: "বেইজিয়ান প্রবাবিলিটি",
      description: "মেশিন লার্নিং-এ ব্যবহৃত শর্তাধীন সম্ভাবনা",
      formula: "P(A|B) = P(B|A)P(A)/P(B)",
      explanation: "বেইজ থিওরেম প্রায়োর নলেজ এবং নতুন এভিডেন্সের ভিত্তিতে প্রবাবিলিটি আপডেট করতে ব্যবহৃত হয়। এটি নেইভ বেইজ ক্লাসিফায়ার সহ অনেক এআই অ্যালগরিদমের ভিত্তি।",
      icon: <Braces className="h-5 w-5 text-primary" />,
      lastUpdated: "২০২৪-০২-১৮"
    },
    {
      title: "বিগ-ও নোটেশন",
      description: "অ্যালগরিদম পারফরম্যান্স এনালাইসিসের জন্য গাণিতিক নোটেশন",
      formula: "O(n), O(log n), O(n²), O(2^n)",
      explanation: "বিগ-ও নোটেশন অ্যালগরিদমের সময় ও স্পেস কমপ্লেক্সিটি প্রকাশ করে। এআই-তে, এফিশিয়েন্ট অ্যালগরিদম তৈরি ও সিলেক্ট করতে এটি গুরুত্বপূর্ণ।",
      icon: <Cpu className="h-5 w-5 text-primary" />,
      lastUpdated: "২০২৪-০১-৩০"
    }
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-6">কৃত্রিম বুদ্ধিমত্তা (এআই) সূত্র ও তত্ত্ব</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {aiTopics.map((topic, index) => (
          <AITopic key={index} {...topic} />
        ))}
      </div>
    </div>
  );
};

export default AIFormulaContent;
