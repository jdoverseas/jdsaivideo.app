
import React, { useEffect, useRef } from "react";
import { ArrowDown, Gamepad, Trophy, Target } from "lucide-react";

const HeroSection: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = document.querySelectorAll(".page-transition-element");
    elements.forEach((el) => observer.observe(el));

    return () => {
      elements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  const scrollToNextSection = () => {
    document.getElementById("games")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="home"
      ref={sectionRef}
      className="relative min-h-screen flex flex-col justify-center items-center px-6 overflow-hidden"
    >
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-primary/10 blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-blue-400/10 blur-3xl animate-float" style={{ animationDelay: '2s' }} />
      </div>
      
      <div className="max-w-5xl mx-auto text-center z-10">
        <span className="inline-block px-3 py-1 mb-6 text-xs font-medium rounded-full bg-primary/10 text-primary page-transition-element">
          মজাদার গেমস
        </span>
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 page-transition-element leading-tight">
          <span className="text-gradient">জেডি</span> গেমস <br/> আপনার সময় উপভোগ করুন
        </h1>
        <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto mb-10 page-transition-element">
          সর্বশ্রেষ্ঠ গেম খেলার অভিজ্ঞতা পেতে জেডি গেমস অ্যাপটি ব্যবহার করুন। বিভিন্ন ধরনের মজার গেমস খেলুন এবং উপভোগ করুন।
        </p>
        
        <div className="flex flex-wrap justify-center gap-4 mb-12 page-transition-element">
          <div className="flex items-center bg-primary/10 rounded-full px-4 py-2">
            <Gamepad className="w-5 h-5 mr-2 text-primary" />
            <span className="text-sm font-medium">১০০+ গেমস</span>
          </div>
          <div className="flex items-center bg-primary/10 rounded-full px-4 py-2">
            <Trophy className="w-5 h-5 mr-2 text-primary" />
            <span className="text-sm font-medium">লিডারবোর্ড</span>
          </div>
          <div className="flex items-center bg-primary/10 rounded-full px-4 py-2">
            <Target className="w-5 h-5 mr-2 text-primary" />
            <span className="text-sm font-medium">চ্যালেঞ্জসমূহ</span>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4 page-transition-element">
          <a 
            href="#games" 
            className="px-8 py-3 rounded-full bg-primary text-white font-medium transition-all hover:shadow-lg hover:shadow-primary/20 hover:-translate-y-0.5 active:translate-y-0"
          >
            গেমস খেলুন
          </a>
          <a 
            href="#features" 
            className="px-8 py-3 rounded-full bg-secondary text-foreground font-medium transition-all hover:bg-secondary/80"
          >
            বৈশিষ্ট্য দেখুন
          </a>
        </div>
      </div>
      
      <button 
        onClick={scrollToNextSection}
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 flex flex-col items-center text-muted-foreground hover:text-foreground transition-colors"
        aria-label="Scroll down"
      >
        <span className="text-sm mb-2">স্ক্রল করুন</span>
        <ArrowDown className="h-4 w-4 animate-bounce" />
      </button>
    </section>
  );
};

export default HeroSection;
