
import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Menu, X, Gamepad, Atom } from "lucide-react";
import { Link } from "react-router-dom";

const Navigation: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { title: "হোম", href: "/" },
    { title: "গেমস", href: "/#games" },
    { title: "বিজ্ঞান সূত্র গেম", href: "/formula-game" },
    { title: "ফিচারস", href: "/#features" },
    { title: "গ্যালারি", href: "/#gallery" },
  ];

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out py-4 px-6 md:px-12",
        isScrolled 
          ? "bg-white/80 dark:bg-black/80 backdrop-blur-md shadow-sm" 
          : "bg-transparent"
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <div className="relative w-8 h-8">
            <div className="absolute w-8 h-8 bg-primary rounded-full opacity-20 animate-pulse-subtle"></div>
            <Gamepad className="absolute w-5 h-5 text-primary top-1.5 left-1.5" />
          </div>
          <span className="font-semibold text-xl">জেডি গেমস</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-10">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className="text-sm font-medium transition-colors hover:text-primary flex items-center"
            >
              {link.title === "বিজ্ঞান সূত্র গেম" && <Atom className="w-4 h-4 mr-1" />}
              {link.title}
            </Link>
          ))}
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden flex items-center justify-center"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>

      {/* Mobile Menu */}
      <div
        className={cn(
          "fixed inset-0 bg-background/95 backdrop-blur-sm z-40 md:hidden transition-all duration-300 ease-in-out",
          mobileMenuOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        )}
      >
        <div className="flex flex-col items-center justify-center h-full space-y-8">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className="text-2xl font-medium transition-colors hover:text-primary flex items-center"
            >
              {link.title === "বিজ্ঞান সূত্র গেম" && <Atom className="w-5 h-5 mr-2" />}
              {link.title}
            </Link>
          ))}
        </div>
      </div>
    </header>
  );
};

export default Navigation;
