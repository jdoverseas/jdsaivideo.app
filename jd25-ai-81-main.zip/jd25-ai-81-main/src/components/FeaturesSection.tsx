
import React, { useEffect, useRef } from "react";

const FeaturesSection: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      const elements = sectionRef.current.querySelectorAll(".page-transition-element");
      elements.forEach((el) => observer.observe(el));
    }

    return () => {
      if (sectionRef.current) {
        const elements = sectionRef.current.querySelectorAll(".page-transition-element");
        elements.forEach((el) => observer.unobserve(el));
      }
    };
  }, []);

  return (
    <section
      id="features"
      ref={sectionRef}
      className="py-24 px-6 md:py-32 bg-secondary/50"
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 md:mb-24">
          <span className="inline-block px-3 py-1 mb-4 text-xs font-medium rounded-full bg-primary/10 text-primary page-transition-element">
            বৈশিষ্ট্য
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 page-transition-element">
            চিন্তাশীলভাবে তৈরি বিবরণ
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto page-transition-element">
            প্রতিটি বৈশিষ্ট্য যত্ন সহকারে নির্বাচিত করা হয়েছে আপনার শিক্ষার অভিজ্ঞতা উন্নত করার জন্য।
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-16">
          <div className="flex flex-col md:flex-row gap-6 page-transition-element">
            <div className="flex-shrink-0">
              <div className="w-12 h-12 rounded-full bg-card shadow-sm flex items-center justify-center text-primary font-semibold">০১</div>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-3">স্মার্ট ফর্মুলা ব্যাখ্যা</h3>
              <p className="text-muted-foreground mb-4">
                পদার্থবিজ্ঞান এবং রসায়নের সূত্রগুলি ধাপে ধাপে ব্যাখ্যা করে, যা আপনাকে মূল ধারণাগুলি বুঝতে সাহায্য করে।
              </p>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">সূত্রের উৎপত্তি এবং ইতিহাস</span>
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">বাস্তব জীবনে প্রয়োগ</span>
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">অনুশীলনী সমস্যা সমাধান</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-6 page-transition-element">
            <div className="flex-shrink-0">
              <div className="w-12 h-12 rounded-full bg-card shadow-sm flex items-center justify-center text-primary font-semibold">০২</div>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-3">ইন্টারেক্টিভ পরীক্ষা</h3>
              <p className="text-muted-foreground mb-4">
                ভার্চুয়াল ল্যাব এবং পরীক্ষাগুলি আপনাকে আসল অভিজ্ঞতা প্রদান করে সূত্রগুলির কার্যকারিতা প্রদর্শন করে।
              </p>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">৩ডি ভিজ্যুয়ালাইজেশন</span>
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">ভার্চুয়াল পরীক্ষাগার</span>
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">তাত্ত্বিক সিমুলেশন</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-6 page-transition-element">
            <div className="flex-shrink-0">
              <div className="w-12 h-12 rounded-full bg-card shadow-sm flex items-center justify-center text-primary font-semibold">০৩</div>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-3">পাঠ্যপুস্তক অ্যাকসেস</h3>
              <p className="text-muted-foreground mb-4">
                বিভিন্ন বোর্ড এবং স্তরের জন্য বাংলা ভাষায় বিভিন্ন পাঠ্যপুস্তকের অ্যাকসেস।
              </p>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">মাধ্যমিক এবং উচ্চ মাধ্যমিক</span>
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">ভর্তি পরীক্ষা প্রস্তুতি</span>
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">বিশ্ববিদ্যালয় স্তরের কোর্স</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-6 page-transition-element">
            <div className="flex-shrink-0">
              <div className="w-12 h-12 rounded-full bg-card shadow-sm flex items-center justify-center text-primary font-semibold">০৪</div>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-3">AI সহায়তা</h3>
              <p className="text-muted-foreground mb-4">
                আপনার প্রশ্নগুলির উত্তর দিতে উন্নত এআই যা বাংলা ভাষায় সহজভাবে বিজ্ঞান বোঝাতে সাহায্য করে।
              </p>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">প্রশ্নের উত্তর</span>
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">পার্সোনালাইজড শিক্ষা</span>
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">শিক্ষার অগ্রগতি ট্র্যাকিং</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
