
import React, { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

const GallerySection: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const images = [
    {
      src: "https://images.unsplash.com/photo-1595941056519-d5e47181e33d?w=800&auto=format&fit=crop&q=80",
      alt: "Minimal desk setup with a sleek device"
    },
    {
      src: "https://images.unsplash.com/photo-1629429407756-446d68170de2?w=800&auto=format&fit=crop&q=80",
      alt: "Close-up detail of the product surface"
    },
    {
      src: "https://images.unsplash.com/photo-1587212639073-3e8405414bbd?w=800&auto=format&fit=crop&q=80",
      alt: "Product in an elegant living space"
    },
    {
      src: "https://images.unsplash.com/photo-1592898741947-bc9de0f7e79f?w=800&auto=format&fit=crop&q=80",
      alt: "Minimalist product showcase"
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      const elements = sectionRef.current.querySelectorAll(".page-transition-element");
      elements.forEach((el) => observer.observe(el));
    }

    return () => {
      if (sectionRef.current) {
        const elements = sectionRef.current.querySelectorAll(".page-transition-element");
        elements.forEach((el) => observer.unobserve(el));
      }
    };
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  return (
    <section
      id="gallery"
      ref={sectionRef}
      className="py-24 px-6 md:py-32"
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 md:mb-24">
          <span className="inline-block px-3 py-1 mb-4 text-xs font-medium rounded-full bg-primary/10 text-primary page-transition-element">
            Gallery
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 page-transition-element">
            Experience the Details
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto page-transition-element">
            A closer look at the craftsmanship and attention to detail that defines our product.
          </p>
        </div>

        <div className="relative page-transition-element">
          <div className="overflow-hidden rounded-2xl shadow-lg">
            <div 
              className="flex transition-transform duration-500 ease-in-out" 
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {images.map((image, index) => (
                <div key={index} className="w-full flex-shrink-0">
                  <img 
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-[400px] md:h-[600px] object-cover"
                    loading="lazy"
                  />
                </div>
              ))}
            </div>
          </div>
          
          <button 
            onClick={prevSlide}
            className="absolute top-1/2 left-4 transform -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 flex items-center justify-center shadow-md hover:bg-white transition-colors"
            aria-label="Previous slide"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          
          <button 
            onClick={nextSlide}
            className="absolute top-1/2 right-4 transform -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 flex items-center justify-center shadow-md hover:bg-white transition-colors"
            aria-label="Next slide"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
          
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {images.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2.5 h-2.5 rounded-full transition-colors ${
                  index === currentSlide ? "bg-primary" : "bg-white/50"
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default GallerySection;
