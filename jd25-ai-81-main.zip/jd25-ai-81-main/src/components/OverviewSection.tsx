
import React, { useEffect, useRef } from "react";
import { Sparkles, Heart, Zap } from "lucide-react";

const OverviewSection: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      const elements = sectionRef.current.querySelectorAll(".page-transition-element");
      elements.forEach((el) => observer.observe(el));
    }

    return () => {
      if (sectionRef.current) {
        const elements = sectionRef.current.querySelectorAll(".page-transition-element");
        elements.forEach((el) => observer.unobserve(el));
      }
    };
  }, []);

  return (
    <section
      id="overview"
      ref={sectionRef}
      className="py-24 px-6 md:py-32 relative"
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 md:mb-24">
          <span className="inline-block px-3 py-1 mb-4 text-xs font-medium rounded-full bg-primary/10 text-primary page-transition-element">
            সংক্ষিপ্ত বিবরণ
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 page-transition-element">
            উদ্দেশ্যমূলক ডিজাইন
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto page-transition-element">
            আমাদের AI সিস্টেমের প্রতিটি দিক চিন্তাশীলভাবে বিবেচনা করা হয়েছে, যাতে আপনি সহজেই বিজ্ঞানের জটিল ধারণাগুলি বুঝতে পারেন।
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          <div className="bg-card rounded-2xl p-8 flex flex-col items-center text-center page-transition-element card-hover">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-5">
              <Sparkles className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-3">সহজ ব্যাখ্যা</h3>
            <p className="text-muted-foreground">
              জটিল বিজ্ঞান ধারণাগুলি সহজ বাংলা ভাষায় ব্যাখ্যা করে সবার জন্য বোধগম্য করে তোলে।
            </p>
          </div>

          <div className="bg-card rounded-2xl p-8 flex flex-col items-center text-center page-transition-element card-hover">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-5">
              <Heart className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-3">ইন্টারেক্টিভ শিক্ষা</h3>
            <p className="text-muted-foreground">
              ব্যবহারকারীর প্রশ্নের উপর ভিত্তি করে কাস্টমাইজড শিক্ষার অভিজ্ঞতা প্রদান করে।
            </p>
          </div>

          <div className="bg-card rounded-2xl p-8 flex flex-col items-center text-center page-transition-element card-hover">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-5">
              <Zap className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-3">সূত্র সমাধান</h3>
            <p className="text-muted-foreground">
              পদার্থবিজ্ঞান এবং রসায়নের জটিল সূত্রগুলি সহজে মনে রাখার কৌশল এবং ধাপে ধাপে সমাধান।
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default OverviewSection;
