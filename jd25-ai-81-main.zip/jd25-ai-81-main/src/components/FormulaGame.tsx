
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Beaker, Atom, RefreshCw, Trophy } from "lucide-react";
import { toast } from "sonner";

// Formula database with categories
const formulas = {
  physics: [
    { name: "অভিকর্ষ সূত্র", formula: "F = G(m₁m₂/r²)", description: "দুটি বস্তুর মধ্যে আকর্ষণ বল" },
    { name: "নিউটনের দ্বিতীয় সূত্র", formula: "F = ma", description: "বল = ভর × ত্বরণ" },
    { name: "আইনস্টাইনের সূত্র", formula: "E = mc²", description: "শক্তি = ভর × আলোর বেগের বর্গ" },
    { name: "আপেক্ষিক বেগ", formula: "v = d/t", description: "বেগ = দূরত্ব ÷ সময়" },
    { name: "ঘনত্ব সূত্র", formula: "ρ = m/V", description: "ঘনত্ব = ভর ÷ আয়তন" },
    { name: "ওহমের সূত্র", formula: "V = IR", description: "ভোল্টেজ = বিদ্যুৎপ্রবাহ × রোধ" }
  ],
  chemistry: [
    { name: "পিএইচ (pH) সূত্র", formula: "pH = -log[H⁺]", description: "হাইড্রোজেন আয়নের ঘনত্বের ঋণাত্মক লগারিদম" },
    { name: "গ্যাসের আদর্শ সূত্র", formula: "PV = nRT", description: "চাপ × আয়তন = মোল সংখ্যা × গ্যাস ধ্রুবক × তাপমাত্রা" },
    { name: "মোলারিটি", formula: "M = n/V", description: "মোলারিটি = মোল সংখ্যা ÷ দ্রবণের আয়তন" },
    { name: "আভোগাড্রো সংখ্যা", formula: "N = 6.022 × 10²³", description: "এক মোল পদার্থে অণুর সংখ্যা" },
    { name: "হেনরির সূত্র", formula: "C = kP", description: "দ্রবণে গ্যাসের দ্রাব্যতা" },
    { name: "অ্যাভোগাড্রোর সূত্র", formula: "V₁/n₁ = V₂/n₂", description: "সমান চাপ ও তাপমাত্রায় গ্যাসের আয়তন তার মোল সংখ্যার সমানুপাতিক" }
  ]
};

// Formula Game component
const FormulaGame: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<"physics" | "chemistry">("physics");
  const [score, setScore] = useState(0);
  const [currentFormula, setCurrentFormula] = useState<any>(null);
  const [options, setOptions] = useState<string[]>([]);
  const [answered, setAnswered] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toLocaleDateString("bn-BD"));
  const [nextUpdate, setNextUpdate] = useState<string>("");

  // Calculate next update date (40 days from now or last update)
  useEffect(() => {
    const calculateNextUpdate = () => {
      const now = new Date();
      const nextDate = new Date(now);
      nextDate.setDate(now.getDate() + 40);
      setNextUpdate(nextDate.toLocaleDateString("bn-BD"));
    };
    
    calculateNextUpdate();
  }, []);

  // Initialize game
  useEffect(() => {
    generateQuestion();
  }, [activeCategory]);

  // Generate a new question
  const generateQuestion = () => {
    const categoryFormulas = formulas[activeCategory];
    const randomIndex = Math.floor(Math.random() * categoryFormulas.length);
    const selected = categoryFormulas[randomIndex];
    
    setCurrentFormula(selected);
    
    // Generate 4 options (1 correct, 3 wrong)
    let allOptions = [selected.formula];
    
    while (allOptions.length < 4) {
      const randomFormulaIndex = Math.floor(Math.random() * categoryFormulas.length);
      const randomFormula = categoryFormulas[randomFormulaIndex].formula;
      
      if (!allOptions.includes(randomFormula)) {
        allOptions.push(randomFormula);
      }
    }
    
    // Shuffle options
    allOptions = allOptions.sort(() => Math.random() - 0.5);
    setOptions(allOptions);
    setAnswered(false);
  };

  // Handle option selection
  const handleOptionSelect = (selectedOption: string) => {
    if (answered) return;
    
    setAnswered(true);
    
    if (selectedOption === currentFormula.formula) {
      setScore(score + 10);
      toast.success("সঠিক উত্তর! +১০ পয়েন্ট");
    } else {
      toast.error(`ভুল উত্তর! সঠিক উত্তর: ${currentFormula.formula}`);
    }
    
    // Generate new question after 1.5 seconds
    setTimeout(generateQuestion, 1500);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div className="flex space-x-2">
          <Button 
            variant={activeCategory === "physics" ? "default" : "outline"} 
            onClick={() => setActiveCategory("physics")}
            className="flex items-center"
          >
            <Atom className="mr-2 h-4 w-4" />
            পদার্থবিজ্ঞান
          </Button>
          <Button 
            variant={activeCategory === "chemistry" ? "default" : "outline"} 
            onClick={() => setActiveCategory("chemistry")}
            className="flex items-center"
          >
            <Beaker className="mr-2 h-4 w-4" />
            রসায়ন
          </Button>
        </div>
        <div className="flex items-center bg-primary/10 px-4 py-2 rounded-lg">
          <Trophy className="text-yellow-500 mr-2" />
          <span className="font-bold">{score} পয়েন্ট</span>
        </div>
      </div>

      {currentFormula && (
        <Card className="mb-6 transition-all hover:shadow-md">
          <CardHeader>
            <CardTitle className="text-2xl">{currentFormula.name}</CardTitle>
            <CardDescription>{currentFormula.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-center text-lg font-bold mb-4">এই সূত্রটি কোনটি?</p>
            <div className="grid grid-cols-2 gap-3">
              {options.map((option, index) => (
                <Button
                  key={index}
                  variant={answered ? (option === currentFormula.formula ? "default" : "outline") : "outline"}
                  className={`text-lg py-6 ${
                    answered && option === currentFormula.formula ? "bg-green-500 hover:bg-green-600" : ""
                  }`}
                  onClick={() => handleOptionSelect(option)}
                  disabled={answered}
                >
                  {option}
                </Button>
              ))}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between items-center text-sm text-muted-foreground">
            <div className="flex items-center">
              <RefreshCw className="h-4 w-4 mr-1" />
              সর্বশেষ আপডেট: {lastUpdated}
            </div>
            <div>
              পরবর্তী আপডেট: {nextUpdate}
            </div>
          </CardFooter>
        </Card>
      )}

      <div className="text-center mt-8">
        <p className="text-sm text-muted-foreground mb-2">
          প্রতি ৪০ দিন অন্তর নতুন সূত্র যোগ করা হয়
        </p>
        <Button onClick={generateQuestion} className="mx-auto">
          <RefreshCw className="mr-2 h-4 w-4" />
          নতুন সূত্র দেখুন
        </Button>
      </div>
    </div>
  );
};

export default FormulaGame;
