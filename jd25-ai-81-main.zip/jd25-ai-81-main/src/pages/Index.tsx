
import React, { useEffect } from "react";
import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import GamesSection from "@/components/GamesSection";
import FeaturesSection from "@/components/FeaturesSection";
import GallerySection from "@/components/GallerySection";
import SpecsSection from "@/components/SpecsSection";
import Footer from "@/components/Footer";

const Index: React.FC = () => {
  // Initialize intersection observer for page transition animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = document.querySelectorAll(".page-transition-element");
    elements.forEach((el) => observer.observe(el));

    return () => {
      elements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  return (
    <div className="min-h-screen">
      <Navigation />
      <div id="home">
        <HeroSection />
      </div>
      <div id="games">
        <GamesSection />
      </div>
      <div id="features">
        <FeaturesSection />
      </div>
      <div id="gallery">
        <GallerySection />
      </div>
      <SpecsSection />
      <Footer />
    </div>
  );
};

export default Index;
