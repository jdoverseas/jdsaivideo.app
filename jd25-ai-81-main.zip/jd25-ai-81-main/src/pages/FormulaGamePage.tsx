
import React from "react";
import Navigation from "@/components/Navigation";
import FormulaGame from "@/components/FormulaGame";
import Footer from "@/components/Footer";

const FormulaGamePage: React.FC = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="container mx-auto px-4 py-20">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">বিজ্ঞান সূত্র গেম</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            পদার্থবিজ্ঞান, রসায়ন এবং কৃত্রিম বুদ্ধিমত্তা (এআই) এর বিভিন্ন সূত্র শিখতে এই মজার গেমটি খেলুন। প্রতি ৪০ দিন অন্তর নতুন সূত্র যোগ করা হয়।
          </p>
        </div>
        <FormulaGame />
      </div>
      <Footer />
    </div>
  );
};

export default FormulaGamePage;
